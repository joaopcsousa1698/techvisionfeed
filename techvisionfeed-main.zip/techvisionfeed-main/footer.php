<footer>
    <div class="text-center p-3">
    © 2020 Copyright: Todos os Direitos Reservados a TechVision
    </div>
</footer>