<!DOCTYPE html>
<html lang="pt-pt">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
         <title>TechVision</title>
      <link rel="icon" href="images/pagelogo.ico">
      <link rel="stylesheet" href="css/navbar.css">
      <link rel="stylesheet" href="css/footer.css">
      <link rel="stylesheet" href="css/paginas.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.js"></script>   
      <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript" src="js/navbar.js"></script>
</head>
   <body>
        <header>
        <?php include_once ('navbar.php'); ?>
        </header> 
        <div class='spacing'></div>
        <section id="about" class="about section-bg">
        <div class="container">
            <div class="row no-gutters">
                <div class="content-left">
                    <div class="content col-xl-12 d-flex align-items-stretch">
                        <div class="content">
                            <h3>Sobre nós</h3>
                            <p>
                            O fórum de notícias TechVision, surgiu através de um projeto pedido pelo IPMAIA no âmbito da unidade curricular Tecnologias de Internet e engloba várias plataformas de comunicação. 
                            </p>
                        </div>
                    </div>

                    <div class="col-xl-12 d-flex align-items-stretch">
                        <div class="icon-boxes d-flex flex-column justify-content-center">
                            <div class="row">
                                <div class="col-md-6 icon-box">
                                    <i class="bx bx-cube-alt"></i>
                                    <h4>Publico Alvo</h4>
                                    <p>Este forum é ideal para Profissionais ligados às tecnologias de informação que procuram uma forma de enriquecer os seus conhecimentos</p>
                                </div>
                                <div class="col-md-6 icon-box">
                                    <i class="bx bx-receipt"></i>
                                    <h4>Objetivo</h4>
                                    <p>Trazer aos utilizadores um meio partilha de notícias tecnológicas da atualidade.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-right">
                    <div class="content col-xl-12 d-flex align-items-stretch">
                        <div class="content">
                            <h3>A equipa</h3>
                            <div class="row">
                                <div class="col-md-4 team-member">
                                <img class="mx-auto rounded-circle" src="images/joao.jpg"/>
                                <h5>João Sousa</h5>
                                </div>
                                <div class="col-md-4 team-member">
                                <img class="mx-auto rounded-circle foto" src="images/ana.png"/>
                                <h5>Ana Carolina</h5>
                                </div>
                                <div class="col-md-4 team-member">
                                <img class="mx-auto rounded-circle" src="images/david.png"/>
                                <h5>David Ferreira</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </section>
        <footer>
        <?php include_once ('footer.php'); ?>
        </footer>
   </body>
</html>