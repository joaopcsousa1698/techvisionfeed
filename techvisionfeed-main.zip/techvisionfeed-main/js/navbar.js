$(document).ready(function() {
    $("#navbarSupportedContent ul li a").css('color', '#000000');
    $(".menu-icon").on("click", function() {
          $("nav ul").toggleClass("showing");
    });

    var img = document.createElement("img");
    img.src = "images/logoBlue.png";
    var src = document.getElementById("logo");
    src.appendChild(img);

    $(window).on("scroll", function() {
      if($(window).scrollTop()) {
            $('nav').removeClass('navbar-light').addClass('navbar-dark text-body');
            $("nav").css('background-color', '#007a99');
            $("#navbarSupportedContent ul li a").css('color', '#FFFFFF');
            img.src = "images/logo.png";
            var src = document.getElementById("logo");
            src.appendChild(img);
            $(".dropdown-item").css('color', '#000000');
            
      }
      else {
            $("nav").css('background-color', 'transparent');
            $("#navbarSupportedContent ul li a").css('color', '#000000');
            $('nav').removeClass('navbar-dark text-body').addClass('navbar-light');
            img.src = "images/logoBlue.png";
            var src = document.getElementById("logo");
            src.appendChild(img);
      }
     });
});


