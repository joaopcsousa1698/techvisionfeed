<!DOCTYPE html>
<html lang="pt-pt">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
         <title>TechVision</title>
      <link rel="icon" href="images/pagelogo.ico">
      <link rel="stylesheet" href="css/navbar.css">
      <link rel="stylesheet" href="css/footer.css">
      <link rel="stylesheet" href="css/paginas.css">
      <link rel="stylesheet" href="css/reader.css">
      <link rel="stylesheet" href="css/noticias.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
      <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript" src="js/navbar.js"></script>
</head>
   <body>
   <?php include_once ('navbar.php'); ?>

    <?php function rss($url){
        include 'reader.php';
    } ?>
      <header>
   <!-- --------------------------------------------------------------------Hardware---------------------------------------------------------------------------- -->
     
      <div class="container"> 
      <div class="titulo">
         <h2>Acompanhe na TechVision as últimas notícias sobre placas gráficas, processadores, memória e tudo aquilo que garante o máximo desempenho do computador.</h2>
      </div>

      <div id="carouselnews" class="carousel slide" data-ride="carousel">
        
         <div class="carousel-inner">
            <div class="carousel-item active">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
         </div>

         <a class="carousel-control-prev" href="#carouselnews" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
         </a>
         <a class="carousel-control-next" href="#carouselnews" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
         </a>
      </div>
      
         <div class="row"> 
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>   
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
         </div> 

         <div class="row"> 
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>   
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
         </div>

         

<!-- -------------------------------------------------------------------Novidades de Software---------------------------------------------------------------- -->
         
      <div class="titulo">
         <h2>Novidades de Software</h2>
      </div>

      <div id="carouselnews" class="carousel slide" data-ride="carousel">
        
         <div class="carousel-inner">
            <div class="carousel-item active">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
         </div>

         <a class="carousel-control-prev" href="#carouselnews" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
         </a>
         <a class="carousel-control-next" href="#carouselnews" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
         </a>
      </div>

         <div class="row"> 
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>   
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
      </div>

         <div class="row"> 
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>   
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div> 
            <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/hardware/feed");
                  ?>
            </div> 
            <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/hardware/feed");
                  ?>
            </div> 
      </div>
 <!-- ---------------------------------------------------------------CiberSegurança------------------------------------------------------------------ -->
         
      <div class="titulo">
         <h2>Proteja-se de ataques informáticos</h2>
      </div>
      
      <div id="carouselnews" class="carousel slide" data-ride="carousel">
        
         <div class="carousel-inner">
            <div class="carousel-item active">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/hardware/feed");
               ?>
            </div>
         </div>

         <a class="carousel-control-prev" href="#carouselnews" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
         </a>
         <a class="carousel-control-next" href="#carouselnews" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
         </a>
      </div>

            <div class="row"> 
               <div class="col-4">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
                  </div>   
               <div class="col-4">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
                  </div> 
               <div class="col-4">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
               </div> 
            </div>

            <div class="row"> 
               <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
                  </div>   
               <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
                  </div> 
               <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
                  </div> 
               <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
                  </div> 
            </div>

<!-- -------------------------------------------------------------------Redes de Comunicação---------------------------------------------------------------- -->
         
      <div class="titulo">
         <h2> Isolamento marca aumento “significativo” de uso das Redes de Comunicações. </h2>
      </div>
   
      <div id="carouselnews" class="carousel slide" data-ride="carousel">
        
         <div class="carousel-inner">
            <div class="carousel-item active">
               <?php
                  rss($url = "https://www.leak.pt/feed/");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/feed/");
               ?>
            </div>
            <div class="carousel-item">
               <?php
                  rss($url = "https://www.leak.pt/feed/");
               ?>
            </div>
         </div>

         <a class="carousel-control-prev" href="#carouselnews" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
         </a>
         <a class="carousel-control-next" href="#carouselnews" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
         </a>
      </div>

         <div class="row"> 
            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/feed");
               ?>
            </div>   

            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/feed");
               ?>
            </div> 

            <div class="col-4">
               <?php
                  rss($url = "https://www.leak.pt/feed");
               ?>
            </div> 
      </div>

         <div class="row"> 
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/feed");
               ?>
            </div>   
            <div class="col-3">
               <?php
                  rss($url = "https://www.leak.pt/feed");
               ?>
            </div> 
            <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
            </div> 
            <div class="col-3">
                  <?php
                     rss($url = "https://www.leak.pt/feed");
                  ?>
            </div> 
      </div>
      
     <footer>
         <?php include_once ('footer.php'); ?>
      </footer> 
   </body>
</html>
