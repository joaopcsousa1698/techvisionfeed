<nav class="navbar navbar-expand-md navbar-light">
  <div class="container-fluid">
    <a class="navbar-brand"><div id="logo"></div></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="ultimas.php">Ultimas</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdown2" data-toggle="dropdown">Categorias</a>                
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Hardware</a>
            <a class="dropdown-item" href="#">Software</a>
            <a class="dropdown-item" href="#">CiberSegurança</a>
            <a class="dropdown-item" href="#">Networking</a>
            <a class="dropdown-item" href="#">Inteligência Artificial</a>
            <a class="dropdown-item" href="#">Sistemas Operativos</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="categorias.php">Ver tudo</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdown3" data-toggle="dropdown">Marcas</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Apple</a>
            <a class="dropdown-item" href="#">Samsung</a>
            <a class="dropdown-item" href="#">Huawei</a>
            <a class="dropdown-item" href="#">Microsoft</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="marcas.php">Ver tudo</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sobre.php">Sobre</a>
        </li>
      </ul>
    </div>
  </div>
</nav>